numero1 = 1
numero2 = 2
iterador = 3
suma = 0
suma = numero1+numero2
if suma>3:
    print(("El numero es mayor a 3"))
else:
    print(("El numero es menor a 3"))
while iterador==3:
    print(("iterador: ",3))
for i in range(0, 5, 1):
    print(("Iteración:",i))
