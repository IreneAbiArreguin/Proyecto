import re
from grammarLenguageListener import grammarLenguageListener
from grammarLenguageParser import *

# Esta clase define un listener para procesar el árbol de análisis generado por LanguageKidCodeParser.
class traductorNewL(ParseTreeListener):
    def __init__(self):
        self.output = ""

    # Método para procesar la declaración de variables
    def enterVariableDeclaration(self, ctx: grammarLenguageParser.VariableDeclarationContext):
        nombre = ctx.ID().getText()  # Nombre de la variable
        valor = ctx.value().getText()  # Valor asignado

        # Manejo de valores booleanos 't' y 'f'
        if valor == "t":  # Traduce 't' a True
            valor = "True"
        elif valor == "f":  # Traduce 'f' a False
            valor = "False"
        self.output += f"{nombre} = {valor}\n"

    # Método para procesar la declaración de arrays
    def enterArrayDeclaration(self, ctx: grammarLenguageParser.ArrayDeclarationContext):
        try:
            nombre = ctx.ID().getText()  # Nombre del array
            tamano = int(ctx.INT().getText())  # Tamaño del array

            # Verifica el tipo del array
            if ctx.INT_TYPE() is not None:  # Enteros
                valor_inicial = "0"
            elif ctx.FLOAT_TYPE() is not None:  # Flotantes
                valor_inicial = "0.0"
            elif ctx.STRING_TYPE() is not None:  # Cadenas
                valor_inicial = '""'
            elif ctx.BOOL_TYPE() is not None:  # Booleanos
                valor_inicial = "False"
            else:
                raise ValueError("Tipo de dato no reconocido en la declaración del array.")

            # Genera el código en Python para el array
            self.output += f"{nombre} = [{valor_inicial}] * {tamano}\n"
        except AttributeError as e:
            print(f"Error procesando la declaración de array: {e}")

    # Método para procesar la declaración de asignaciones
    def enterAssignment(self, ctx: grammarLenguageParser.AssignmentContext):
        try:
            variable = ctx.ID().getText()  # Nombre de la variable

            # Obtener el valor de la expresión o booleano a asignar
            valor_expresion = None
            if ctx.expression():
                valor_expresion = ctx.expression().getText()

            if valor_expresion == "t":
                valor_expresion = "True"
            elif valor_expresion == "f":
                valor_expresion = "False"

            # Generar la línea de asignación en Python
            if valor_expresion is not None:
                self.output += f"{variable} = {valor_expresion}\n"
            else:
                raise Exception("Error: La asignación no contiene una expresión válida.")
        except AttributeError as e:
            print(f"Error procesando la asignación: {e}")

    # Método para procesar la declaración 'si'
    def enterIfDeclaration(self, ctx: grammarLenguageParser.IfDeclarationContext):
        try:
            condicion = ctx.expression().getText()  # La expresión principal
            self.output += f"if {condicion}:\n"

            # Procesar las declaraciones dentro del bloque 'if'
            for decl in ctx.declaration():
                self.processDeclaration(decl, "if")
        except AttributeError as e:
            print(f"Error procesando la declaración 'si': {e}")

    # Método para procesar la cláusula 'si no'
    def enterElseIfClause(self, ctx: grammarLenguageParser.ElseIfClauseContext):
        try:
            condicion = ctx.expression().getText()
            self.output += f"elif {condicion}:\n"

            for decl in ctx.declaration():
                self.processDeclaration(decl, "if")
        except AttributeError as e:
            print(f"Error procesando la cláusula 'si no': {e}")

    # Método para procesar la cláusula 'sino'
    def enterElseDeclaration(self, ctx: grammarLenguageParser.ElseDeclarationContext):
        try:
            self.output += "else:\n"

            for decl in ctx.declaration():
                self.processDeclaration(decl, "if")
        except AttributeError as e:
            print(f"Error procesando la cláusula 'sino': {e}")

    # Método para procesar la declaración 'mientras'
    def enterWhileDeclaration(self, ctx: grammarLenguageParser.WhileDeclarationContext):
        try:
            condicion = ctx.expression().getText()  # La expresión principal
            self.output += f"while {condicion}:\n"

            # Procesar las declaraciones dentro del bloque 'while'
            for decl in ctx.declaration():
                self.processDeclaration(decl, "while")
        except AttributeError as e:
            print(f"Error procesando la declaración 'mientras': {e}")

    # Método para procesar la declaración 'para'
    def enterForDeclaration(self, ctx: grammarLenguageParser.ForDeclarationContext):
        inicio = ctx.ID().getText()
        expresion_inicio = ctx.expression(0).getText()
        expresion_condicion = ctx.expression(1).getText()

        # Expresión regular para extraer el número (o la parte derecha de la expresión)
        resultado = re.search(r'[<>=x]*\s*(\d+)', expresion_condicion)

        # Si hay un resultado, lo usamos; de lo contrario, devolvemos la expresión original
        if resultado:
            expresion_condicion = resultado.group(1)
        paso = ctx.expression(2).getText() if ctx.expression(2) is not None else "1"
        
        self.output += f"for {inicio} in range({expresion_inicio}, {expresion_condicion}, {paso}):\n"
        for decl in ctx.declaration():
            self.processDeclaration(decl, "for")

    def processDeclaration(self, decl, context):
        try:
            # Validar si la declaración existe
            if not decl:
                raise ValueError("La declaración está vacía o es inválida.")

            # Obtener texto de la declaración y eliminar espacios innecesarios
            decl_text = decl.getText().strip()

            # Remover punto final si existe
            if decl_text.endswith('.'):
                decl_text = decl_text[:-1]

            # Procesar declaraciones específicas
            if decl_text.startswith("mostrar"):
                # Extraer contenido después de 'mostrar'
                contenido = decl_text[7:].strip()
                contenido = contenido.replace(';', ',')  # Reemplazar ';' por ','
                self.output += f"    print({contenido})\n"

            # Procesar contextos específicos ('while', 'for', 'if')
            elif context in ["while", "for", "if"]:
                self.output += f"    {decl_text}\n"

            # Manejar declaraciones no reconocidas
            else:
                raise ValueError(f"Declaración no reconocida: {decl_text}")

        except AttributeError as e:
            print(f"Error procesando la declaración (AttributeError): {e}")
        except ValueError as e:
            print(f"Error procesando la declaración (ValueError): {e}")
        except Exception as e:
            print(f"Error inesperado procesando la declaración: {e}")