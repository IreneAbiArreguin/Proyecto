from antlr4 import *
from grammarLenguageLexer import grammarLenguageLexer
from grammarLenguageParser import grammarLenguageParser
from traductor import traductorNewL

def main():
    in_code = input('Nombre del archivo de entrada:')  # Solicitamos el nombre del archivo de entrada
    try:
        with open(in_code, 'r', encoding='utf-8') as fileope:
            content = fileope.read().strip()  # Eliminar espacios extra o caracteres no visibles
            lexer = grammarLenguageLexer(InputStream(content))  # Procesamos el contenido con el lexer
            stream = CommonTokenStream(lexer)
            parser = grammarLenguageParser(stream)
            tree = parser.program()  # Obtenemos el árbol de análisis (parse tree)

            traductor_obj = traductorNewL()  # Instanciamos el traductor
            walker = ParseTreeWalker()
            walker.walk(traductor_obj, tree)  # Recorremos el árbol con el traductor

            # Archivo Python
            nombre_archivo_salida = in_code.replace('.txt', '.py')  # Generamos el nombre del archivo de salida
            with open(nombre_archivo_salida, 'w', encoding='utf-8') as archivo_salida:
                archivo_salida.write(traductor_obj.output)  # Escribimos el código Python traducido

            print(f"El archivo ha sido generado correctamente con el nombre: {nombre_archivo_salida}")

    except FileNotFoundError:
        print(f"El archivo '{in_code}' no existe.")
    except Exception as e:
        print(f"Error procesando el archivo: {e}")

if __name__ == "__main__":
    main()
