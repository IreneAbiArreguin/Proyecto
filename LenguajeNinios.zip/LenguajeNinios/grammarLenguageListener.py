# Generated from c:/Users/Irene/Desktop/AutomataAntelr/LenguajeNinios/grammarLenguage.g4 by ANTLR 4.13.2
from antlr4 import *
if "." in __name__:
    from .grammarLenguageParser import grammarLenguageParser
else:
    from grammarLenguageParser import grammarLenguageParser

# This class defines a complete listener for a parse tree produced by grammarLenguageParser.
class grammarLenguageListener(ParseTreeListener):

    # Enter a parse tree produced by grammarLenguageParser#program.
    def enterProgram(self, ctx:grammarLenguageParser.ProgramContext):
        pass

    # Exit a parse tree produced by grammarLenguageParser#program.
    def exitProgram(self, ctx:grammarLenguageParser.ProgramContext):
        pass


    # Enter a parse tree produced by grammarLenguageParser#declaration.
    def enterDeclaration(self, ctx:grammarLenguageParser.DeclarationContext):
        pass

    # Exit a parse tree produced by grammarLenguageParser#declaration.
    def exitDeclaration(self, ctx:grammarLenguageParser.DeclarationContext):
        pass


    # Enter a parse tree produced by grammarLenguageParser#variableDeclaration.
    def enterVariableDeclaration(self, ctx:grammarLenguageParser.VariableDeclarationContext):
        pass

    # Exit a parse tree produced by grammarLenguageParser#variableDeclaration.
    def exitVariableDeclaration(self, ctx:grammarLenguageParser.VariableDeclarationContext):
        pass


    # Enter a parse tree produced by grammarLenguageParser#value.
    def enterValue(self, ctx:grammarLenguageParser.ValueContext):
        pass

    # Exit a parse tree produced by grammarLenguageParser#value.
    def exitValue(self, ctx:grammarLenguageParser.ValueContext):
        pass


    # Enter a parse tree produced by grammarLenguageParser#bool_value.
    def enterBool_value(self, ctx:grammarLenguageParser.Bool_valueContext):
        pass

    # Exit a parse tree produced by grammarLenguageParser#bool_value.
    def exitBool_value(self, ctx:grammarLenguageParser.Bool_valueContext):
        pass


    # Enter a parse tree produced by grammarLenguageParser#arrayDeclaration.
    def enterArrayDeclaration(self, ctx:grammarLenguageParser.ArrayDeclarationContext):
        pass

    # Exit a parse tree produced by grammarLenguageParser#arrayDeclaration.
    def exitArrayDeclaration(self, ctx:grammarLenguageParser.ArrayDeclarationContext):
        pass


    # Enter a parse tree produced by grammarLenguageParser#assignment.
    def enterAssignment(self, ctx:grammarLenguageParser.AssignmentContext):
        pass

    # Exit a parse tree produced by grammarLenguageParser#assignment.
    def exitAssignment(self, ctx:grammarLenguageParser.AssignmentContext):
        pass


    # Enter a parse tree produced by grammarLenguageParser#expressionDeclaration.
    def enterExpressionDeclaration(self, ctx:grammarLenguageParser.ExpressionDeclarationContext):
        pass

    # Exit a parse tree produced by grammarLenguageParser#expressionDeclaration.
    def exitExpressionDeclaration(self, ctx:grammarLenguageParser.ExpressionDeclarationContext):
        pass


    # Enter a parse tree produced by grammarLenguageParser#expression.
    def enterExpression(self, ctx:grammarLenguageParser.ExpressionContext):
        pass

    # Exit a parse tree produced by grammarLenguageParser#expression.
    def exitExpression(self, ctx:grammarLenguageParser.ExpressionContext):
        pass


    # Enter a parse tree produced by grammarLenguageParser#ifElseDeclaration.
    def enterIfElseDeclaration(self, ctx:grammarLenguageParser.IfElseDeclarationContext):
        pass

    # Exit a parse tree produced by grammarLenguageParser#ifElseDeclaration.
    def exitIfElseDeclaration(self, ctx:grammarLenguageParser.IfElseDeclarationContext):
        pass


    # Enter a parse tree produced by grammarLenguageParser#ifDeclaration.
    def enterIfDeclaration(self, ctx:grammarLenguageParser.IfDeclarationContext):
        pass

    # Exit a parse tree produced by grammarLenguageParser#ifDeclaration.
    def exitIfDeclaration(self, ctx:grammarLenguageParser.IfDeclarationContext):
        pass


    # Enter a parse tree produced by grammarLenguageParser#elseIfClause.
    def enterElseIfClause(self, ctx:grammarLenguageParser.ElseIfClauseContext):
        pass

    # Exit a parse tree produced by grammarLenguageParser#elseIfClause.
    def exitElseIfClause(self, ctx:grammarLenguageParser.ElseIfClauseContext):
        pass


    # Enter a parse tree produced by grammarLenguageParser#elseDeclaration.
    def enterElseDeclaration(self, ctx:grammarLenguageParser.ElseDeclarationContext):
        pass

    # Exit a parse tree produced by grammarLenguageParser#elseDeclaration.
    def exitElseDeclaration(self, ctx:grammarLenguageParser.ElseDeclarationContext):
        pass


    # Enter a parse tree produced by grammarLenguageParser#whileDeclaration.
    def enterWhileDeclaration(self, ctx:grammarLenguageParser.WhileDeclarationContext):
        pass

    # Exit a parse tree produced by grammarLenguageParser#whileDeclaration.
    def exitWhileDeclaration(self, ctx:grammarLenguageParser.WhileDeclarationContext):
        pass


    # Enter a parse tree produced by grammarLenguageParser#forDeclaration.
    def enterForDeclaration(self, ctx:grammarLenguageParser.ForDeclarationContext):
        pass

    # Exit a parse tree produced by grammarLenguageParser#forDeclaration.
    def exitForDeclaration(self, ctx:grammarLenguageParser.ForDeclarationContext):
        pass


    # Enter a parse tree produced by grammarLenguageParser#showDeclaration.
    def enterShowDeclaration(self, ctx:grammarLenguageParser.ShowDeclarationContext):
        pass

    # Exit a parse tree produced by grammarLenguageParser#showDeclaration.
    def exitShowDeclaration(self, ctx:grammarLenguageParser.ShowDeclarationContext):
        pass


    # Enter a parse tree produced by grammarLenguageParser#showContent.
    def enterShowContent(self, ctx:grammarLenguageParser.ShowContentContext):
        pass

    # Exit a parse tree produced by grammarLenguageParser#showContent.
    def exitShowContent(self, ctx:grammarLenguageParser.ShowContentContext):
        pass



del grammarLenguageParser