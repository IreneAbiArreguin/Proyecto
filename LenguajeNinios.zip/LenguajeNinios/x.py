x = 10
y = 3.14
mensaje = "Hola mundo"
esVerdadero = True
miArreglo = [0] * 5
x = x+5
y = y*2
esVerdadero = False
if x==15:
    print(("x es igual a 15"))
elif x==5:
    print(("Así lo defini"))
while x<20:
    print(("x es menor que 20"))
    x=x+1
x = x+1
for i in range(0, 5, 1):
    print(("Iteración:",i))
